import{l as o,a as r}from"../chunks/CS3cXRBn.js";export{o as load_css,r as start};
