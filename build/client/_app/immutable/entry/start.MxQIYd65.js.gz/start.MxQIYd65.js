import{l as o,a as r}from"../chunks/yho2i2lu.js";export{o as load_css,r as start};
