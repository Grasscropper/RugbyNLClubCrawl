import{l as o,a as r}from"../chunks/C-8D0NRp.js";export{o as load_css,r as start};
