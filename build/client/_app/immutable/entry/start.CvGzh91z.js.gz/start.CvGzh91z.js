import{l as o,a as r}from"../chunks/36-zbK8S.js";export{o as load_css,r as start};
