import"../chunks/CWj6FrbW.js";import"../chunks/DazqCHCy.js";import{b as a,a as p}from"../chunks/DH7zvddy.js";var t=a("<div>HELLO WORLD</div>");function v(o){var r=t();p(o,r)}export{v as component};
